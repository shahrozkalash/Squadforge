console.log("App loaded",import.meta.env.VITE_API_ENDPOINT);
