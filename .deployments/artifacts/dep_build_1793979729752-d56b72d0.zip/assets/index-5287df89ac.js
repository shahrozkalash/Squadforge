console.log("App loaded","https://api.squadforge.app");
